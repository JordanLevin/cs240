#ifndef ANTHILL_H
#define ANTHILL_H

#include "LinkedList.h"
#include "Ant.h"
#include <fstream>
#include <iostream>

class AntHill{
    private:
        int current_ants;
        List* ants;
        int next_id;
        int food;
        int gridSize;
        int turnCount;
		int attackCount;
		int defenseFail;
		int defenseSuccess;
    public:
        std::ofstream stream;
        AntHill();
        int addAnt();
        bool removeAnt(int);
        Ant * getAnt(int);
        void move();
        void printHillInfo();
        int getCurrentNumAnts(){return current_ants;}
        void turn();
        ~AntHill();
};


#endif
