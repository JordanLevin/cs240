CS240 Data Structures and Algorithms
Spring 2017
Project 1 README FILE

Due Date: 2/22/17
Submission Date: 2/21/17
Author(s): Jordan Levin

PERCENT COMPLETE:
100%

PARTS THAT ARE NOT COMPLETE:
none

BUGS:
none

FILES:
Ant.h
Ant.cpp
AntHill.h
AntHill.cpp
LinkedList.h
LinkedList.cpp
project1.cpp
makefile
anthill.log
readme.txt
LinkedListTester.cpp (file for testing the linked list only)

TO RUN:
extract the zip
make
make run
make checkmem
make clean

EXTRA CREDIT:
N/A

BIBLIOGRAPHY:
Google

MISCELLANEOUS:
nope

